function add(a, b) {
  console.log(a + b);
}
add(3, 4);
add(2, 9);

function greet() {
  console.log("Hello");
}
greet();

function add(a, b) {
  return a + b;
}
console.log(add(3, 4));
console.log(add(2, 9));

const num = prompt("Enter a number");
if (num > 0) {
  console.log("positive");
} else {
  console.log("negative");
}
const number = prompt("Enter a number");
if (number > 0) {
  console.log("positive");
} else if (number == 0) {
  console.log("0");
} else {
  console.log("negative");
}

const n = prompt("Enter a number");
if (n > 0) {
  console.log("positive");
}

const numerator = 100,
  deno = 10;
try {
  console.log(numerator / deno);
} catch (error) {
  console.log("An error caught");
  console.log("Error Message" + error);
} finally {
  console.log("finally will execute every time");
}

const numerator1 = 100,
  denom = a;
try {
  console.log(numer / denom);
  console.log(a);
} catch (error) {
  console.log("An error caught");
  console.log("Error Message" + error);
} finally {
  console.log("finally will execute every time");
}